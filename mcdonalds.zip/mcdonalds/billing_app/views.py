from django.shortcuts import render

def home(request):
    return render(request, 'billing_app/home.html')
